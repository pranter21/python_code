num_a = int(input("ingrese el numero:\n"))
num_b = int(input("ingrese el numero:\n"))
suma = 0
resultado = (num_a + num_b)
for i in range(resultado):
	suma += resultado
print("el resultado es: " + str(suma))
