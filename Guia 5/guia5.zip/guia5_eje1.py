num = int(input("ingrese un numero"))
result = num % 2
if result == 1:
        num -= 1
while result == 100:
	int(input("el numero par es: " + (result)))
